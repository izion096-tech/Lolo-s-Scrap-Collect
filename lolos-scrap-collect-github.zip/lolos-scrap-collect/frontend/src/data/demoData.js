import { materialCatalogue } from './materialCatalogue.js';
const get = code => materialCatalogue.find(m=>m.code===code);
const row=(id,date,sellerRef,code,netKg,buyRate,status='Received',extra={})=>{const m=get(code);return {id,date,sellerRef,materialCode:code,materialName:m?.name||code,category:m?.category||'Other',netKg,buyRate,estimatedValue:netKg*buyRate,status,provenance:'Documented',hazard:false, ...extra}};
export const demoIntakes=[
row('IN-1048','2026-10-15','SUP-1001','CU-INSULATED',42.5,62),row('IN-1047','2026-10-15','SUP-1002','AL-EXTRUDE',126,28),row('IN-1046','2026-10-15','SUP-1003','FE-LIGHT',218,2.8),row('IN-1045','2026-10-15','SUP-1004','PCB-PC-MB',18.4,43),row('IN-1044','2026-10-14','SUP-1005','CU-BURNT',8.6,0,'Review',{provenance:'Unknown',hazard:true}),row('IN-1043','2026-10-14','SUP-1006','EL-MOTOR-SM',74,12),row('IN-1042','2026-10-14','SUP-1007','CU-BUSBAR',21,95,'Review',{provenance:'Disputed'}),row('IN-1041','2026-10-13','SUP-1008','FE-HMS1',465,3.2),row('IN-1040','2026-10-12','SUP-1001','PCB-RAM',4.8,55),row('IN-1039','2026-10-11','SUP-1002','CU-BRIGHT',15,95),row('IN-1038','2026-10-10','SUP-1006','BAT-LEAD',36,3,'Review',{hazard:true}),row('IN-1037','2026-10-09','SUP-1003','FE-CAST',85,2.8)
];
export const demoSuppliers=[
{sellerRef:'SUP-1001',label:'Suburban collector A',type:'Community collector',verification:'Verified'},
{sellerRef:'SUP-1002',label:'Cape Valley Repairs',type:'Business / workshop',verification:'Verified'},
{sellerRef:'SUP-1003',label:'Rural collector B',type:'Community collector',verification:'Verified'},
{sellerRef:'SUP-1004',label:'Western Suburbs IT',type:'Business / IT refresh',verification:'Verified'},
{sellerRef:'SUP-1005',label:'Walk-in supplier 231',type:'Walk-in',verification:'Pending'},
{sellerRef:'SUP-1006',label:'Boland Farm Services',type:'Farm / rural',verification:'Verified'},
{sellerRef:'SUP-1007',label:'Workshop supplier C',type:'Business / workshop',verification:'Pending'},
{sellerRef:'SUP-1008',label:'Estate collection',type:'Estate / body corporate',verification:'Verified'}
];
export const weeklyTrend=[{day:'Thu',kg:320},{day:'Fri',kg:480},{day:'Sat',kg:390},{day:'Sun',kg:170},{day:'Mon',kg:620},{day:'Tue',kg:550},{day:'Wed',kg:740}];
