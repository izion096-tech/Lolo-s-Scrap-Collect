# LoLo's Scrap Collect (Pty) Ltd.

**A South African scrap-collection operations and analytics MVP** for material grading, collections, stock movements, profitability, supplier relationships, and compliance record preparation.

> **Important:** This is a development starter and operational prototype, not a legal opinion, government-system integration, approved weighing system, payment processor, or production security certification. Before live trade, have the workflows reviewed by a South African attorney/compliance specialist, register/confirm the applicable dealer/recycler status with SAPS, and validate every regulatory field and retention rule against the current law and current official forms. Draft Metal Trade System proposals are treated as configurable controls until promulgation/status is confirmed.

## Features

- Graphic-rich responsive React dashboard using Recharts and Lucide icons.
- Material taxonomy for ferrous, non-ferrous, cables, automotive, e-waste, batteries, motors/transformers and special/hold categories.
- Board-specific e-waste taxonomy: server/telecom, computer/laptop, expansion cards, power boards, appliance/TV/display boards, RAM, CPU classes, gold fingers, connectors, and mixed boards.
- Intake capture with gross/tare/net weight, supplier/source, buyer-defined rate, electronic-payment reference, identity-verification status, vehicle registration, photos checklist, cable-burnt declaration, and exception flags.
- Transparent guardrails: unresolved counterparty checks, missing source/ID checks, unusual/copper/cable loads, burnt cable, hazardous items, missing payout reference, and non-positive weight can place an intake on hold for human review.
- Operations analytics: intake weight/value, material mix, trend line, margin where a resale value is recorded, stock reconciliation and explainable review flags.
- Privacy-conscious client analytics: repeat supply, frequency, lot size, source-channel mix and retention. No automated guilt/risk score on people; flags describe transaction facts and require authorised human review.
- CSV export helper for acquisition/disposal reporting preparation; it does not submit to the Metal Trade System.
- Local demo persistence in browser `localStorage` so a reviewer can try it immediately.
- FastAPI/SQLite API scaffold, tests, Docker Compose, and reference documentation.

## Run the user interface

Requirements: Node.js 20+ and npm.

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`). The UI runs in demo mode and saves prototype actions in the browser. Do not enter real identity numbers, financial account details, or other sensitive personal information into the demo.

## Run the API scaffold

Requirements: Python 3.11+.

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

API documentation: `http://localhost:8000/docs`.

The front end is currently a self-contained demo using seeded browser data; the API is an included backend scaffold for the next integration step. Do not assume the local demo's browser storage is a secure or compliant system of record.

## Docker (development)

```bash
docker compose up --build
```

Frontend: `http://localhost:5173`  
API docs: `http://localhost:8000/docs`

## Repository layout

```text
.
├── frontend/                 # React + Vite interface
│   ├── public/               # App icon and favicon
│   └── src/
│       ├── components/       # Shared UI components
│       ├── data/             # Configurable material catalogue + demo data
│       ├── lib/              # Analytics, guardrails, formatting, storage
│       ├── App.jsx
│       ├── main.jsx
│       └── styles.css
├── backend/                  # FastAPI + SQLite API scaffold
├── data/                     # Exportable material catalogue
├── docs/                     # Compliance, analytics and deployment notes
├── docker-compose.yml
└── README.md
```

## Before production

1. Replace demo browser storage with an authenticated API and role-based access control.
2. Encrypt identity/document fields at rest and in transit; configure key management, retention, backups, least privilege, access logs and breach response.
3. Complete the POPIA assessment, information officer/operator arrangements, privacy notices, retention schedule, data-subject request workflow and security compromise process.
4. Validate the current Second-Hand Goods Act requirements, SAPS registration, controlled-metal definitions, registers, record retention, payment rules, exemptions and all current amendments with qualified counsel.
5. Confirm whether the proposed 12 July 2024 Metal Trade System amendments or any later replacements were promulgated and what official reporting interface/format is live. The included report is an internal CSV preparation aid only.
6. Confirm e-waste/battery handling, environmental authorisations, municipal zoning, transport and storage requirements for the specific operation.
7. Integrate a real payment provider and certified/legal-for-trade scale workflow; never mark a payment complete from a typed reference alone.
8. Add audit tamper-evidence, backups, monitoring, access reviews, dependency scanning, threat modelling and penetration testing.

## Research notes

See `docs/COMPLIANCE_REGISTER.md`, `docs/MATERIAL_CATALOGUE.md`, and `docs/ANALYTICS_GOVERNANCE.md`. Links point to official government/authority sources where practical.
